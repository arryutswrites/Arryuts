
document.getElementById('uploadForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const name = this.querySelector('input').value;
  const text = this.querySelector('textarea').value;
  const posts = document.getElementById('posts');
  const post = document.createElement('div');
  post.innerHTML = `<h4>${name}</h4><p>${text}</p><hr>`;
  posts.prepend(post);
  this.reset();
});
